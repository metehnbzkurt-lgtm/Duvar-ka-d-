# QuickLandscapeWallpaper (Manzara Duvar Kağıdı)

Ana ekrandaki simgeye her tıklandığında **Wallhaven API** (ücretsiz, anahtarsız ve reklamsız) üzerinden yalnızca **4K / HD dikey manzara** duvar kağıtları çekip cihazın ana ekranına ve kilit ekranına uygulayan minimal Android uygulaması.

## Özellikler
- **Sadece Manzara Filtresi:** `landscape`, `nature+mountains`, `scenic+nature`, `forest+lake`, `sunset+landscape`, `ocean+coast+landscape`, `alpine+mountains` sorgularıyla yalnızca doğa ve manzara görselleri getirir.
- **HD ve Dikey Ekran Uyumu:** `atleast=1080x1920` ve `ratios=9x16,9x18` parametreleriyle telefon ekranına tam oturan yüksek çözünürlüklü görseller seçer.
- **Bellek Koruması:** `BitmapFactory.Options` ile büyük 4K görselleri `OutOfMemoryError` vermeden ekran çözünürlüğüne göre ölçekler.
- **Çevrimdışı Yedek:** İnternet bağlantısı yoksa `res/drawable` içindeki yedek manzara duvar kağıtlarını sırayla uygular.

## Derleme (GitHub Actions)
1. Bu zip'i açmadan repo köküne yükle.
2. Repo'da `.github/workflows/build-from-zip.yml` iş akışı olmalı; zip'i kendisi açıp derler.
3. Actions sekmesi → "Zip'ten APK Derle" → bitince **Artifacts** bölümünden APK'yı indir.

Gradle wrapper kullanılmaz; iş akışı Gradle 8.9'u kendisi kurar. Sürümler Kombi Kontrol ile aynıdır
(AGP 8.5.2, Kotlin 1.9.24, SDK 34). İmza anahtarı `app/duvar-key.p12`: silme, repo özel kalsın.
