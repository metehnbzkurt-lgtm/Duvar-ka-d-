plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.quickwallpaper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.quickwallpaper"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // SABİT imza anahtarı: her GitHub derlemesi aynı anahtarla imzalanır, yeni APK eskisinin
    // üzerine güncelleme olarak kurulur. Anahtarı SİLME / DEĞİŞTİRME, repo'yu özel (private) tut.
    signingConfigs {
        create("duvar") {
            storeFile = file("duvar-key.p12")
            storeType = "pkcs12"
            storePassword = "duvarkagidi23"
            keyAlias = "duvar"
            keyPassword = "duvarkagidi23"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("duvar")
        }
        release {
            signingConfig = signingConfigs.getByName("duvar")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
