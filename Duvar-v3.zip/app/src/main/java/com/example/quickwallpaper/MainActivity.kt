package com.example.quickwallpaper

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "landscape_wallpaper_prefs"
        private const val KEY_FALLBACK_INDEX = "fallback_index"
        private const val KEY_LAST_URL = "last_wallpaper_url"

        // Sadece manzara / doğa odaklı arama sorguları (Wallhaven API - ücretsiz, anahtarsız, reklamsız)
        private val LANDSCAPE_QUERIES = listOf(
            "landscape",
            "nature+mountains",
            "scenic+nature",
            "forest+lake",
            "sunset+landscape",
            "ocean+coast+landscape",
            "alpine+mountains"
        )
    }

    private val activityJob = Job()
    private val uiScope = CoroutineScope(Dispatchers.Main + activityJob)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        toast("Manzara duvar kağıdı getiriliyor...")

        uiScope.launch {
            try {
                val success = try {
                    fetchAndApplyOnlineLandscapeWallpaper()
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
                if (success) {
                    toast("Yeni manzara duvar kağıdı uygulandı")
                } else {
                    val message = try {
                        withContext(Dispatchers.IO) { applyLocalFallbackWallpaper() }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        "Duvar kağıdı ayarlanamadı"
                    }
                    toast(message)
                }
            } finally {
                finish()
            }
        }
    }

    private fun toast(text: String) {
        Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
    }

    private suspend fun fetchAndApplyOnlineLandscapeWallpaper(): Boolean = withContext(Dispatchers.IO) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastUrl = prefs.getString(KEY_LAST_URL, null)
        val randomQuery = LANDSCAPE_QUERIES.random()

        // purity=100 -> Sadece SFW (temiz içerik)
        // categories=100 -> General kategorisi
        // sorting=random -> Her tıklamada rastgele sonuç
        // atleast=1080x1920 -> Yüksek çözünürlük (HD / 4K)
        // ratios=9x16,9x18 -> Telefon ekranına uygun dikey oranlar
        val apiUrl =
            "https://wallhaven.cc/api/v1/search?q=$randomQuery&categories=100&purity=100&sorting=random&atleast=1080x1920&ratios=9x16,9x18"

        val jsonText = httpGetString(apiUrl) ?: return@withContext false
        val root = JSONObject(jsonText)
        val dataArray = root.optJSONArray("data") ?: return@withContext false
        if (dataArray.length() == 0) return@withContext false

        val paths = (0 until dataArray.length())
            .map { dataArray.getJSONObject(it).optString("path", "") }
            .filter { it.isNotBlank() }
        val selectedImageUrl = paths.firstOrNull { it != lastUrl } ?: paths.firstOrNull()
            ?: return@withContext false

        val bitmap = downloadSampledBitmap(selectedImageUrl) ?: return@withContext false
        try {
            applyBitmapToWallpaper(bitmap)
            prefs.edit().putString(KEY_LAST_URL, selectedImageUrl).apply()
            true
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    private fun applyLocalFallbackWallpaper(): String {
        val fallbacks = listOf(
            R.drawable.wallpaper_1,
            R.drawable.wallpaper_2,
            R.drawable.wallpaper_3
        )
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val index = prefs.getInt(KEY_FALLBACK_INDEX, 0).coerceIn(0, fallbacks.size - 1)

        val bitmap = BitmapFactory.decodeResource(resources, fallbacks[index])
            ?: return "Yedek duvar kağıdı yüklenemedi"
        try {
            applyBitmapToWallpaper(bitmap)
            prefs.edit().putInt(KEY_FALLBACK_INDEX, (index + 1) % fallbacks.size).apply()
            return "Çevrimdışı yedek manzara (${index + 1}/${fallbacks.size}) ayarlandı"
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
    }

    private fun applyBitmapToWallpaper(bitmap: Bitmap) {
        val wallpaperManager = WallpaperManager.getInstance(applicationContext)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            // Ana ekran ve kilit ekranını birlikte günceller
            val flags = WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
            wallpaperManager.setBitmap(bitmap, null, true, flags)
        } else {
            wallpaperManager.setBitmap(bitmap)
        }
    }

    private fun httpGetString(urlString: String): String? {
        val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "QuickLandscapeWallpaper/1.0")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                null
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun downloadBytes(imageUrl: String): ByteArray? {
        val connection = (URL(imageUrl).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 20000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "QuickLandscapeWallpaper/1.0")
        }
        return try {
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.use { it.readBytes() }
            } else {
                null
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun downloadSampledBitmap(imageUrl: String): Bitmap? {
        val metrics = resources.displayMetrics
        val targetWidth = metrics.widthPixels.coerceAtLeast(1080)
        val targetHeight = metrics.heightPixels.coerceAtLeast(1920)

        val bytes = downloadBytes(imageUrl) ?: return null

        // Boyutları belleğe tam açmadan oku
        val boundsOptions = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOptions)
        if (boundsOptions.outWidth <= 0 || boundsOptions.outHeight <= 0) return null

        // Ekran çözünürlüğüne uygun örnekleme oranıyla çöz
        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = calculateInSampleSize(boundsOptions, targetWidth, targetHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions)
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height: Int, width: Int) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    override fun onDestroy() {
        super.onDestroy()
        activityJob.cancel()
    }
}
