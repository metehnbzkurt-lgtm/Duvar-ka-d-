package com.bingwall.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

object Module {
    @Volatile
    private var instance: Controller? = null

    fun store(context: Context): Store = Store(context)

    fun controller(context: Context): Controller {
        instance?.let { return it }
        synchronized(this) {
            instance?.let { return it }
            val app = context.applicationContext
            return Controller(Store(app), WallpaperSetter(app)) { app.isUnmetered() }
                .also { instance = it }
        }
    }
}

fun Context.isUnmetered(): Boolean {
    val cm = getSystemService(ConnectivityManager::class.java) ?: return false
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
}
