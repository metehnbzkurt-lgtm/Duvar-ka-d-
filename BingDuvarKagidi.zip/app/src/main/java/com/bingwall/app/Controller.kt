package com.bingwall.app

/**
 * Bing görsel listesini yönetir ve sıradaki / bugünün görselini uygular.
 * Ağ ve dosya işleri yaptığı için ana iş parçacığından çağrılmamalıdır.
 */
class Controller(
    private val store: Store,
    private val setter: WallpaperSetter,
    private val isUnmetered: () -> Boolean,
) {
    /** Simgeye/widget'a dokununca: listedeki sıradaki görsel (en yeniden eskiye, sonra başa döner). */
    @Synchronized
    fun next(): WallpaperResult = advance(latest = false, force = false)

    /** Günlük işte: bugünün görseli. [force] true ise zaten uygulanmış olsa da yeniden uygular. */
    @Synchronized
    fun applyLatest(force: Boolean): WallpaperResult = advance(latest = true, force = force)

    private fun advance(latest: Boolean, force: Boolean): WallpaperResult {
        val state = store.load()
        if (state.wifiOnly && !isUnmetered()) {
            return WallpaperResult.Failed(WallpaperResult.Reason.WIFI_ONLY)
        }

        val now = System.currentTimeMillis()
        var items = state.items
        var fetchedAt = state.lastFetchAt
        val stale = now - state.lastFetchAt > REFRESH_AFTER_MS
        if (latest || items.isEmpty() || stale) {
            try {
                items = BingClient.fetch()
                fetchedAt = now
            } catch (e: Exception) {
                if (items.isEmpty()) {
                    return WallpaperResult.Failed(WallpaperResult.Reason.NETWORK)
                }
            }
        }
        if (items.isEmpty()) return WallpaperResult.Failed(WallpaperResult.Reason.NETWORK)
        if (fetchedAt != state.lastFetchAt) setter.retainOnly(items.map { it.id }.toSet())

        val applied = state.applied
        val currentIndex = items.indexOfFirst { it.id == applied?.id }
        val targetIndex = when {
            latest -> 0
            currentIndex < 0 -> 0
            else -> (currentIndex + 1) % items.size
        }
        val item = items[targetIndex]

        if (latest && !force && item.id == applied?.id) {
            store.save(state.copy(items = items, lastFetchAt = fetchedAt))
            return WallpaperResult.Unchanged
        }
        if (!setter.apply(item, state.destination, state.scrollable)) {
            return WallpaperResult.Failed(WallpaperResult.Reason.SET_WALLPAPER)
        }
        store.save(
            state.copy(
                items = items,
                applied = item,
                lastFetchAt = fetchedAt,
                lastSwitchAt = now,
            )
        )
        prefetchNext(items[(targetIndex + 1) % items.size], state.scrollable)
        return WallpaperResult.Applied(item)
    }

    /** Sıradaki görseli arka planda indirir; bir sonraki dokunuş anında olsun. */
    private fun prefetchNext(item: BingItem, scrollable: Boolean) {
        Thread { setter.prefetch(item, scrollable) }.apply { isDaemon = true }.start()
    }

    private companion object {
        const val REFRESH_AFTER_MS = 6 * 60 * 60 * 1000L
    }
}
