package com.bingwall.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Görseli indirir (diskte önbellekler) ve duvar kağıdı olarak uygular.
 * Ana iş parçacığından çağrılmamalıdır.
 */
class WallpaperSetter(context: Context) {
    private val app = context.applicationContext
    private val cacheDir = File(app.cacheDir, "wallpapers").apply { mkdirs() }

    fun apply(item: BingItem, dest: Destination, scrollable: Boolean): Boolean {
        val source = loadBitmap(item, scrollable) ?: return false
        val bitmap = if (scrollable) source else centerCrop(source)
        val wm = WallpaperManager.getInstance(app)
        if (!wm.isSetWallpaperAllowed) return false
        return try {
            wm.setBitmap(bitmap, null, true, flags(dest))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Bir sonraki dokunuşun hızlı olması için görseli önceden indirip diske kaydeder. */
    fun prefetch(item: BingItem, scrollable: Boolean) {
        for (suffix in suffixes(scrollable)) {
            if (cachedOrDownload(item, suffix) != null) return
        }
    }

    /** Listede olmayan görsellerin önbelleğini siler. */
    fun retainOnly(ids: Set<String>) {
        cacheDir.listFiles()?.forEach { file ->
            if (ids.none { file.name.startsWith(it + "__") }) file.delete()
        }
    }

    private fun flags(dest: Destination): Int = when (dest) {
        Destination.HOME -> WallpaperManager.FLAG_SYSTEM
        Destination.LOCK -> WallpaperManager.FLAG_LOCK
        Destination.BOTH -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
    }

    /**
     * Kırpılacaksa dikey (1080x1920) görsel, kaydırılabilirse UHD istenir.
     * Küçük dosya hem daha hızlı iner hem daha hızlı çözülür ve sisteme yazılır.
     */
    private fun suffixes(scrollable: Boolean): List<String> =
        if (scrollable) listOf("_UHD.jpg", "_1920x1080.jpg")
        else listOf("_1080x1920.jpg", "_1920x1080.jpg")

    private fun loadBitmap(item: BingItem, scrollable: Boolean): Bitmap? {
        for (suffix in suffixes(scrollable)) {
            val bytes = cachedOrDownload(item, suffix) ?: continue
            val bitmap = try {
                decodeSampled(bytes)
            } catch (e: OutOfMemoryError) {
                null
            }
            if (bitmap != null) return bitmap
            cacheFile(item, suffix).delete() // bozuk dosya
        }
        return null
    }

    private fun cacheFile(item: BingItem, suffix: String) =
        File(cacheDir, "${item.id}__$suffix")

    private fun cachedOrDownload(item: BingItem, suffix: String): ByteArray? {
        val file = cacheFile(item, suffix)
        if (file.exists() && file.length() > 0) {
            return try {
                file.readBytes()
            } catch (e: Exception) {
                null
            }
        }
        val url = item.imageUrl.removeSuffix("_UHD.jpg") + suffix
        val bytes = download(url) ?: return null
        try {
            file.writeBytes(bytes)
        } catch (e: Exception) {
            // önbelleğe yazılamasa da görsel kullanılabilir
        }
        return bytes
    }

    private fun download(url: String): ByteArray? {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 12_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            try {
                if (conn.responseCode != HttpURLConnection.HTTP_OK) null
                else conn.inputStream.use { it.readBytes() }
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Ekranı kaplamaya yetecek boyutun çok üstüne çıkmadan çözer (bellek tasarrufu). */
    private fun decodeSampled(bytes: ByteArray): Bitmap? {
        val dm = app.resources.displayMetrics
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outHeight / (sample * 2) >= dm.heightPixels &&
            bounds.outWidth / (sample * 2) >= dm.widthPixels
        ) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Ekran oranında ortadan kırpar, ekran boyutuna getirir. */
    private fun centerCrop(src: Bitmap): Bitmap {
        val dm = app.resources.displayMetrics
        val tw = dm.widthPixels.coerceAtLeast(1)
        val th = dm.heightPixels.coerceAtLeast(1)
        val targetRatio = tw.toFloat() / th
        val srcRatio = src.width.toFloat() / src.height
        val cw: Int
        val ch: Int
        if (srcRatio > targetRatio) {
            cw = (src.height * targetRatio).toInt().coerceIn(1, src.width)
            ch = src.height
        } else {
            cw = src.width
            ch = (src.width / targetRatio).toInt().coerceIn(1, src.height)
        }
        val x = (src.width - cw) / 2
        val y = (src.height - ch) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, ch)
        return if (cropped.width == tw && cropped.height == th) cropped
        else Bitmap.createScaledBitmap(cropped, tw, th, true)
    }
}
