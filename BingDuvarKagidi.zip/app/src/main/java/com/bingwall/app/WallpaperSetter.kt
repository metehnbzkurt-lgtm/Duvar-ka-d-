package com.bingwall.app

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL

/** Görseli arka plan iş parçacığında indirir ve duvar kağıdı olarak uygular. */
class WallpaperSetter(context: Context) {
    private val app = context.applicationContext

    fun apply(item: BingItem, dest: Destination, scrollable: Boolean): Boolean {
        val source = download(item.imageUrl)
            ?: download(item.imageUrl.replace("_UHD.jpg", "_1920x1080.jpg"))
            ?: return false
        val bitmap = if (scrollable) source else centerCrop(source)
        val wm = WallpaperManager.getInstance(app)
        if (!wm.isSetWallpaperAllowed) return false
        return try {
            wm.setBitmap(bitmap, null, true, flags(dest))
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun flags(dest: Destination): Int = when (dest) {
        Destination.HOME -> WallpaperManager.FLAG_SYSTEM
        Destination.LOCK -> WallpaperManager.FLAG_LOCK
        Destination.BOTH -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
    }

    private fun download(url: String): Bitmap? {
        return try {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 12_000
            conn.readTimeout = 30_000
            conn.instanceFollowRedirects = true
            try {
                if (conn.responseCode != HttpURLConnection.HTTP_OK) null
                else decodeSampled(conn.inputStream.use { it.readBytes() })
            } finally {
                conn.disconnect()
            }
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    /** Ekranı kaplamaya yetecek boyutun çok üstüne çıkmadan çözer (bellek tasarrufu). */
    private fun decodeSampled(bytes: ByteArray): Bitmap? {
        val dm = app.resources.displayMetrics
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outHeight / (sample * 2) >= dm.heightPixels &&
            bounds.outWidth / (sample * 2) >= dm.widthPixels
        ) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    /** Ekran oranında ortadan kırpar, ekran boyutuna getirir. */
    private fun centerCrop(src: Bitmap): Bitmap {
        val dm = app.resources.displayMetrics
        val tw = dm.widthPixels.coerceAtLeast(1)
        val th = dm.heightPixels.coerceAtLeast(1)
        val targetRatio = tw.toFloat() / th
        val srcRatio = src.width.toFloat() / src.height
        val cw: Int
        val ch: Int
        if (srcRatio > targetRatio) {
            cw = (src.height * targetRatio).toInt().coerceIn(1, src.width)
            ch = src.height
        } else {
            cw = src.width
            ch = (src.width / targetRatio).toInt().coerceIn(1, src.height)
        }
        val x = (src.width - cw) / 2
        val y = (src.height - ch) / 2
        val cropped = Bitmap.createBitmap(src, x, y, cw, ch)
        return if (cropped.width == tw && cropped.height == th) cropped
        else Bitmap.createScaledBitmap(cropped, tw, th, true)
    }
}
