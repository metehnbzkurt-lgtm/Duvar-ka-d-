package com.bingwall.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("bing_wallpaper", Context.MODE_PRIVATE)

    @Synchronized
    fun load(): State = State(
        destination = runCatching {
            Destination.valueOf(prefs.getString("destination", null) ?: "HOME")
        }.getOrDefault(Destination.HOME),
        scrollable = prefs.getBoolean("scrollable", false),
        wifiOnly = prefs.getBoolean("wifi_only", true),
        dailyEnabled = prefs.getBoolean("daily_enabled", true),
        items = runCatching { decodeList(prefs.getString("items", null)) }.getOrDefault(emptyList()),
        applied = runCatching {
            prefs.getString("applied", null)?.let { decodeItem(JSONObject(it)) }
        }.getOrNull(),
        lastFetchAt = prefs.getLong("last_fetch_at", 0L),
        lastSwitchAt = prefs.getLong("last_switch_at", 0L),
    )

    @Synchronized
    fun save(state: State) {
        val items = JSONArray()
        state.items.forEach { items.put(encodeItem(it)) }
        prefs.edit()
            .putString("destination", state.destination.name)
            .putBoolean("scrollable", state.scrollable)
            .putBoolean("wifi_only", state.wifiOnly)
            .putBoolean("daily_enabled", state.dailyEnabled)
            .putString("items", items.toString())
            .putString("applied", state.applied?.let { encodeItem(it).toString() })
            .putLong("last_fetch_at", state.lastFetchAt)
            .putLong("last_switch_at", state.lastSwitchAt)
            .apply()
    }

    private fun encodeItem(i: BingItem): JSONObject = JSONObject()
        .put("id", i.id)
        .put("url", i.imageUrl)
        .put("title", i.title)
        .put("copyright", i.copyright)
        .put("link", i.link)

    private fun decodeItem(o: JSONObject): BingItem = BingItem(
        id = o.getString("id"),
        imageUrl = o.getString("url"),
        title = o.optString("title"),
        copyright = o.optString("copyright"),
        link = o.optString("link"),
    )

    private fun decodeList(raw: String?): List<BingItem> {
        if (raw.isNullOrBlank()) return emptyList()
        val arr = JSONArray(raw)
        return List(arr.length()) { decodeItem(arr.getJSONObject(it)) }
    }
}
