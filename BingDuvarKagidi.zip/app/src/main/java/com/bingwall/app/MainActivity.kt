package com.bingwall.app

import android.app.Activity
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.net.URL

class MainActivity : Activity() {
    private lateinit var store: Store
    private lateinit var preview: ImageView
    private lateinit var headline: TextView
    private lateinit var credit: TextView
    private lateinit var buttons: List<Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Module.store(this)
        setContentView(buildUi())
        refreshInfo()
        syncSchedule()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val state = store.load()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFFDDDDDD.toInt())
        }
        root.addView(
            preview,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)),
        )
        headline = TextView(this).apply {
            textSize = 18f
            setPadding(0, dp(12), 0, 0)
        }
        credit = TextView(this).apply { textSize = 12f }
        root.addView(headline)
        root.addView(credit)

        root.addView(sectionLabel(R.string.section_destination))
        val group = RadioGroup(this)
        listOf(
            R.string.dest_home to Destination.HOME,
            R.string.dest_lock to Destination.LOCK,
            R.string.dest_both to Destination.BOTH,
        ).forEach { (label, dest) ->
            group.addView(RadioButton(this).apply {
                setText(label)
                id = View.generateViewId()
                tag = dest
                isChecked = state.destination == dest
            })
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            val dest = g.findViewById<View>(checkedId)?.tag as? Destination
                ?: return@setOnCheckedChangeListener
            store.save(store.load().copy(destination = dest))
        }
        root.addView(group)

        root.addView(toggle(R.string.opt_wifi_only, state.wifiOnly) { on ->
            store.save(store.load().copy(wifiOnly = on))
            syncSchedule()
        })
        root.addView(toggle(R.string.opt_scrollable, state.scrollable) { on ->
            store.save(store.load().copy(scrollable = on))
        })
        root.addView(toggle(R.string.opt_daily, state.dailyEnabled) { on ->
            store.save(store.load().copy(dailyEnabled = on))
            syncSchedule()
        })
        root.addView(TextView(this).apply {
            setText(R.string.hint_daily)
            textSize = 12f
        })

        val next = Button(this).apply {
            setText(R.string.btn_next)
            setOnClickListener { perform { it.next() } }
        }
        val today = Button(this).apply {
            setText(R.string.btn_today)
            setOnClickListener { perform { it.applyLatest(force = true) } }
        }
        buttons = listOf(next, today)
        root.addView(next, topMargin(dp(20)))
        root.addView(today)

        return ScrollView(this).apply { addView(root) }
    }

    private fun topMargin(px: Int) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT,
    ).apply { topMargin = px }

    private fun sectionLabel(res: Int) = TextView(this).apply {
        setText(res)
        textSize = 14f
        setPadding(0, dp(20), 0, dp(4))
    }

    private fun toggle(res: Int, checked: Boolean, onChange: (Boolean) -> Unit) =
        Switch(this).apply {
            setText(res)
            isChecked = checked
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }

    private fun perform(action: (Controller) -> WallpaperResult) {
        buttons.forEach { it.isEnabled = false }
        val app = applicationContext
        Toast.makeText(app, R.string.msg_working, Toast.LENGTH_SHORT).show()
        Thread {
            val result = action(Module.controller(app))
            runOnUiThread {
                buttons.forEach { it.isEnabled = true }
                Toast.makeText(app, Messages.describe(app, result), Toast.LENGTH_LONG).show()
                refreshInfo()
            }
        }.start()
    }

    private fun refreshInfo() {
        val applied = store.load().applied
        if (applied == null) {
            headline.setText(R.string.no_wallpaper_yet)
            credit.text = ""
            return
        }
        headline.text = applied.headline
        credit.text = applied.copyright
        val thumbUrl = applied.imageUrl.replace("_UHD.jpg", "_320x240.jpg")
        Thread {
            val bmp = try {
                val conn = URL(thumbUrl).openConnection().apply {
                    connectTimeout = 10_000
                    readTimeout = 15_000
                }
                conn.getInputStream().use { BitmapFactory.decodeStream(it) }
            } catch (e: Exception) {
                null
            }
            if (bmp != null) runOnUiThread { preview.setImageBitmap(bmp) }
        }.start()
    }

    private fun syncSchedule() {
        val s = store.load()
        if (s.dailyEnabled) DailyWorker.schedule(this, s.wifiOnly) else DailyWorker.cancel(this)
    }
}
