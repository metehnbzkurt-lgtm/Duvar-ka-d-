package com.bingwall.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Bing ana sayfa görsel arşivinden son görselleri alır (idx=0 bugün, 1 dün, ...). */
object BingClient {
    private const val HOST = "https://www.bing.com"

    @Throws(IOException::class)
    fun fetch(market: String = "tr-TR", count: Int = 8): List<BingItem> {
        val url = URL("$HOST/HPImageArchive.aspx?format=js&idx=0&n=$count&mkt=$market")
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 12_000
        conn.readTimeout = 20_000
        try {
            if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                throw IOException("HTTP ${conn.responseCode}")
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(text).getJSONArray("images")
            return List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                BingItem(
                    id = o.optString("startdate") + "_" + o.optString("hsh"),
                    imageUrl = HOST + o.getString("urlbase") + "_UHD.jpg",
                    title = o.optString("title"),
                    copyright = o.optString("copyright"),
                    link = o.optString("copyrightlink"),
                )
            }
        } catch (e: org.json.JSONException) {
            throw IOException("Bing yanıtı okunamadı", e)
        } finally {
            conn.disconnect()
        }
    }
}
