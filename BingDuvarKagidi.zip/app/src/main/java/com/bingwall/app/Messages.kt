package com.bingwall.app

import android.content.Context

object Messages {
    fun describe(context: Context, result: WallpaperResult): String = when (result) {
        is WallpaperResult.Applied ->
            context.getString(R.string.msg_applied, result.item.headline)
        WallpaperResult.Unchanged -> context.getString(R.string.msg_unchanged)
        is WallpaperResult.Failed -> when (result.reason) {
            WallpaperResult.Reason.WIFI_ONLY -> context.getString(R.string.msg_wifi_only)
            WallpaperResult.Reason.NETWORK -> context.getString(R.string.msg_network)
            WallpaperResult.Reason.SET_WALLPAPER -> context.getString(R.string.msg_failed)
        }
    }
}
