package com.bingwall.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/**
 * Görünmez, şeffaf etkinlik: widget'a veya Nova kısayoluna dokununca sıradaki
 * Bing görselini arka planda uygular, sonucu bildirir ve kapanır.
 */
class SwitchWallpaperActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = applicationContext
        val main = Handler(Looper.getMainLooper())
        Toast.makeText(app, R.string.msg_working, Toast.LENGTH_SHORT).show()
        Thread {
            val result = Module.controller(app).next()
            main.post {
                Toast.makeText(app, Messages.describe(app, result), Toast.LENGTH_LONG).show()
                finish()
            }
        }.start()
    }
}
