package com.bingwall.app

enum class Destination { HOME, LOCK, BOTH }

data class BingItem(
    val id: String,
    val imageUrl: String,
    val title: String,
    val copyright: String,
    val link: String,
) {
    /** Kısa başlık: Bing başlık vermezse telif metninin ilk kısmı kullanılır. */
    val headline: String
        get() = title.ifBlank { copyright.substringBefore("(©").trim() }.ifBlank { copyright }
}

data class State(
    val destination: Destination = Destination.HOME,
    val scrollable: Boolean = false,
    val wifiOnly: Boolean = true,
    val dailyEnabled: Boolean = true,
    val items: List<BingItem> = emptyList(),
    val applied: BingItem? = null,
    val lastFetchAt: Long = 0L,
    val lastSwitchAt: Long = 0L,
)

sealed class WallpaperResult {
    data class Applied(val item: BingItem) : WallpaperResult()
    data object Unchanged : WallpaperResult()
    data class Failed(val reason: Reason) : WallpaperResult()

    enum class Reason { WIFI_ONLY, NETWORK, SET_WALLPAPER }
}
