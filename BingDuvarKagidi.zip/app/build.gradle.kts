plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bingwall.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bingwall.app"
        minSdk = 26
        targetSdk = 34
        // Her yeni sürümde versionCode'u artır (güncelleme için gerekli)
        versionCode = 2
        versionName = "1.1"
    }

    // Her derleme aynı anahtarla imzalanır; böylece yeni APK eskisinin üstüne güncellenir.
    signingConfigs {
        create("fixed") {
            storeFile = file("signing.jks")
            storePassword = "bingwall123"
            keyAlias = "bingwall"
            keyPassword = "bingwall123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
