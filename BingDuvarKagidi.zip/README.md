# Bing Duvar Kağıdı

Bing'in günlük görselini duvar kağıdı yapan küçük Android uygulaması (Nova Launcher ile uyumlu, Android 8+; Android 14 için hedeflendi).

## APK'yı zip yükleyerek derleme (GitHub)
1. Depoda **Add file → Create new file** ile `.github/workflows/build-from-zip.yml` dosyasını oluştur (içeriği `build-from-zip.yml` dosyasından kopyala) ve commit et.
2. **Add file → Upload files** ile bu zip dosyasını depo ana dizinine yükle ve commit et. Zip'i açma, olduğu gibi yükle.
3. **Actions** sekmesinde "Build APK from zip" bitince **Artifacts** altından `BingDuvarKagidi-apk` dosyasını indir. Zip'ten çıkan `app-debug.apk` dosyasını telefona kur.

Yeni bir sürüm için yeni zip'i yüklemen yeterli; en son yüklenen zip derlenir.

## Kullanım
- Uygulamayı aç: hedefi (ana ekran / kilit / ikisi), Wi-Fi ve günlük değişim ayarlarını seç.
- **Nova'da widget:** ana ekrana uzun bas → Widget'lar → "Bing Duvar Kağıdı" → 1x1 widget'ı yerleştir. Dokununca sıradaki görsele geçer.
- **Nova'da kısayol (alternatif):** ana ekrana uzun bas → Widget'lar → Nova "Etkinlikler" (Activities) → "Duvar kağıdını değiştir".
- Günlük değişim her sabah 07:00 civarında çalışır. Telefon pil tasarrufu uygulamayı kısıtlarsa, uygulamayı pil kısıtlamasından muaf tut.
